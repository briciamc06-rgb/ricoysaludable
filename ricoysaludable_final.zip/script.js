// Buscador en index.html
const buscador = document.getElementById("buscador");
if (buscador) {
  buscador.addEventListener("keyup", () => {
    let filtro = buscador.value.toLowerCase();
    document.querySelectorAll(".receta").forEach(r => {
      let texto = r.innerText.toLowerCase();
      r.style.display = texto.includes(filtro) ? "" : "none";
    });
  });
}

// Reseñas (simple)
function enviarResena() {
  const textarea = document.querySelector(".resenas textarea");
  const lista = document.getElementById("listaResenas");
  if (textarea.value.trim() !== "") {
    const p = document.createElement("p");
    p.textContent = textarea.value;
    lista.appendChild(p);
    textarea.value = "";
  }
}

// Estrellas
document.querySelectorAll(".estrellas").forEach(stars => {
  stars.addEventListener("click", e => {
    let rating = [...stars.textContent].indexOf(e.target.textContent) + 1;
    stars.setAttribute("data-rating", rating);
    stars.innerHTML = "★★★★★".split("").map((s, i) =>
      i < rating ? `<span class="activo">${s}</span>` : s
    ).join("");
  });
});